from django.shortcuts import render, redirect
from .forms import SongUploadForm  # Import your form
from .models import Song


def index(request):
    songs = Song.objects.all()
    context = {
        'songs': songs
    }
    return render(request, 'home/index.html', context)

def upload_song(request):
    if request.method == 'POST':
        form = SongUploadForm(request.POST, request.FILES)
        if form.is_valid():
            # Process form data (save to database, handle file upload, etc.)
            form.save()
            return redirect('home')  # Redirect to home or another page after successful upload
    else:
        form = SongUploadForm()
    
    return render(request, 'home/upload.html', {'form': form})

'''
def index(request):
    songs = Song.objects.all()
    context = {
        'songs': songs
    }
    return render(request, 'index.html', context)'''