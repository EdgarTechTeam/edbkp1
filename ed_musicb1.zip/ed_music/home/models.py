from django.db import models

# Create your models here.


class Song(models.Model):
    song_name = models.CharField(max_length=100)
    artist_name = models.CharField(max_length=100)
    song_tag = models.CharField(max_length=50, blank=True)
    description = models.TextField(blank=True)
    audio_file = models.FileField(upload_to='songs/audio/', blank=True)
    image = models.ImageField(upload_to='songs/images/', blank=True)

    def __str__(self):
        return self.song_name